/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9117647058823529, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-6"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-0"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-11"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-7"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-10"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-2"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-1"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/jmeter.apache.org\/"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-2"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-3"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-4"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-5"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-8"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-7"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-9"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-4"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-3"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-6"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html-5"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-4"], "isController": false}, {"data": [1.0, 500, 1500, "GetStarted_Tx"], "isController": true}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-3"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-6"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-5"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-7"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/jmeter.apache.org\/-0"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/-1"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-0"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-2"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/download_jmeter.cgi-1"], "isController": false}, {"data": [1.0, 500, 1500, "Downloadpage_Tx"], "isController": true}, {"data": [1.0, 500, 1500, "https:\/\/jmeter.apache.org\/usermanual\/get-started.html"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 31, 0, 0.0, 367.25806451612914, 40, 3497, 131.0, 452.4, 3113.599999999999, 3497.0, 0.4557952156205431, 7.502615538573507, 0.4502528468822137], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["https:\/\/jmeter.apache.org\/-6", 1, 0, 0.0, 341.0, 341, 341, 341.0, 341.0, 341.0, 341.0, 2.932551319648094, 102.09230663489735, 1.4748671187683284], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-0", 1, 0, 0.0, 141.0, 141, 141, 141.0, 141.0, 141.0, 141.0, 7.092198581560283, 448.97634086879435, 3.6499889184397167], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-11", 1, 0, 0.0, 56.0, 56, 56, 56.0, 56.0, 56.0, 56.0, 17.857142857142858, 50.31040736607143, 9.434291294642858], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-7", 1, 0, 0.0, 210.0, 210, 210, 210.0, 210.0, 210.0, 210.0, 4.761904761904763, 98.7397693452381, 2.455357142857143], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-10", 1, 0, 0.0, 64.0, 64, 64, 64.0, 64.0, 64.0, 64.0, 15.625, 76.6754150390625, 8.4228515625], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-2", 1, 0, 0.0, 131.0, 131, 131, 131.0, 131.0, 131.0, 131.0, 7.633587786259541, 7.067032442748092, 4.465350667938931], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-1", 1, 0, 0.0, 290.0, 290, 290, 290.0, 290.0, 290.0, 290.0, 3.4482758620689653, 8.462419181034484, 1.9733297413793105], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/", 1, 0, 0.0, 3497.0, 3497, 3497, 3497.0, 3497.0, 3497.0, 3497.0, 0.28595939376608526, 40.93966703603088, 1.1678536960251644], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-2", 1, 0, 0.0, 277.0, 277, 277, 277.0, 277.0, 277.0, 277.0, 3.6101083032490977, 105.00690997292418, 1.9354975180505414], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-3", 1, 0, 0.0, 453.0, 453, 453, 453.0, 453.0, 453.0, 453.0, 2.207505518763797, 23.68972475165563, 1.1145315949227372], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-4", 1, 0, 0.0, 178.0, 178, 178, 178.0, 178.0, 178.0, 178.0, 5.617977528089887, 29.55473139044944, 2.8419066011235956], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-5", 1, 0, 0.0, 365.0, 365, 365, 365.0, 365.0, 365.0, 365.0, 2.73972602739726, 74.81271404109589, 1.3885916095890412], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-8", 1, 0, 0.0, 47.0, 47, 47, 47.0, 47.0, 47.0, 47.0, 21.27659574468085, 162.56648936170214, 11.136968085106384], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-7", 1, 0, 0.0, 113.0, 113, 113, 113.0, 113.0, 113.0, 113.0, 8.849557522123893, 2.7309181415929205, 5.314919800884955], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-9", 1, 0, 0.0, 48.0, 48, 48, 48.0, 48.0, 48.0, 48.0, 20.833333333333332, 252.44140625, 10.945638020833334], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-4", 1, 0, 0.0, 132.0, 132, 132, 132.0, 132.0, 132.0, 132.0, 7.575757575757576, 1.827355587121212, 4.475911458333333], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi", 1, 0, 0.0, 397.0, 397, 397, 397.0, 397.0, 397.0, 397.0, 2.5188916876574305, 41.47807777078086, 11.649874055415616], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-3", 1, 0, 0.0, 116.0, 116, 116, 116.0, 116.0, 116.0, 116.0, 8.620689655172413, 2.2561961206896552, 4.663927801724138], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-6", 1, 0, 0.0, 41.0, 41, 41, 41.0, 41.0, 41.0, 41.0, 24.390243902439025, 6.407202743902439, 13.147865853658535], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html-5", 1, 0, 0.0, 116.0, 116, 116, 116.0, 116.0, 116.0, 116.0, 8.620689655172413, 2.2646147629310343, 4.680765086206896], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-4", 1, 0, 0.0, 41.0, 41, 41, 41.0, 41.0, 41.0, 41.0, 24.390243902439025, 5.883193597560975, 14.410251524390244], "isController": false}, {"data": ["GetStarted_Tx", 1, 0, 0.0, 450.0, 450, 450, 450.0, 450.0, 450.0, 450.0, 2.2222222222222223, 212.23307291666666, 14.672309027777777], "isController": true}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-3", 1, 0, 0.0, 41.0, 41, 41, 41.0, 41.0, 41.0, 41.0, 24.390243902439025, 6.383384146341463, 14.386432926829269], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-6", 1, 0, 0.0, 40.0, 40, 40, 40.0, 40.0, 40.0, 40.0, 25.0, 6.5673828125, 14.697265625], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-5", 1, 0, 0.0, 40.0, 40, 40, 40.0, 40.0, 40.0, 40.0, 25.0, 6.5673828125, 14.794921875], "isController": false}, {"data": ["Test", 1, 0, 0.0, 3497.0, 3497, 3497, 3497.0, 3497.0, 3497.0, 3497.0, 0.28595939376608526, 40.93966703603088, 1.1678536960251644], "isController": true}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-7", 1, 0, 0.0, 41.0, 41, 41, 41.0, 41.0, 41.0, 41.0, 24.390243902439025, 7.526676829268292, 14.6484375], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-0", 1, 0, 0.0, 2858.0, 2858, 2858, 2858.0, 2858.0, 2858.0, 2858.0, 0.3498950314905528, 4.470729093771868, 0.1708471833449965], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/-1", 1, 0, 0.0, 422.0, 422, 422, 422.0, 422.0, 422.0, 422.0, 2.3696682464454977, 5.815406546208531, 1.2403732227488151], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-0", 1, 0, 0.0, 286.0, 286, 286, 286.0, 286.0, 286.0, 286.0, 3.4965034965034967, 41.08391608391609, 1.7721536276223777], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-2", 1, 0, 0.0, 48.0, 48, 48, 48.0, 48.0, 48.0, 48.0, 20.833333333333332, 19.287109375, 12.186686197916666], "isController": false}, {"data": ["https:\/\/jmeter.apache.org\/download_jmeter.cgi-1", 1, 0, 0.0, 105.0, 105, 105, 105.0, 105.0, 105.0, 105.0, 9.523809523809526, 23.372395833333336, 5.450148809523809], "isController": false}, {"data": ["Downloadpage_Tx", 1, 0, 0.0, 397.0, 397, 397, 397.0, 397.0, 397.0, 397.0, 2.5188916876574305, 41.47807777078086, 11.649874055415616], "isController": true}, {"data": ["https:\/\/jmeter.apache.org\/usermanual\/get-started.html", 1, 0, 0.0, 450.0, 450, 450, 450.0, 450.0, 450.0, 450.0, 2.2222222222222223, 212.23307291666666, 14.672309027777777], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 31, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
